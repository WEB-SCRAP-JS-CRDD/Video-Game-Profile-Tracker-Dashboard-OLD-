package com.example.testbarchart

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
